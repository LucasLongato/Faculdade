package modelo;

public interface Curso {
    boolean verificarAprovacao(Estudante estudante);
}
