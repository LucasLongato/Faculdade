package categoriadecurso;

public class CursandoMestrado extends Matriculado{
	
	public CursandoMestrado(Matriculado matricula) {
		super(matricula);	
	}
	@Override
	public String matricula() {
		// TODO Auto-generated method stub
		return matricula.matricula()+"Aluno matriculado no Mestrado";
	}
}