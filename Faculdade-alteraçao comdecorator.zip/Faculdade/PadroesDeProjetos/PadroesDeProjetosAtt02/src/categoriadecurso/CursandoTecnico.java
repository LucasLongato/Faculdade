package categoriadecurso;

public class CursandoTecnico {

}
