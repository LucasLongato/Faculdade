package categoriadecurso;

public interface Matricula {

}
