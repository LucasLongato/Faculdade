package categoriadecurso;

public class cursobas implements Matricula{
	@Override
	public String matricula(){
		return "MATRICULA INICIADA\n";
	}
}
