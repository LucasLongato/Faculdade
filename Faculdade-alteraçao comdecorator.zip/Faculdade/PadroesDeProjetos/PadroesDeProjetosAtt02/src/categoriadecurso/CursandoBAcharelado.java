package categoriadecurso;

public class CursandoBAcharelado extends Matriculado{
	
	public CursandoBAcharelado(Matriculado matricula) {
		super(matricula);	
	}
	@Override
	public String matricula() {
		// TODO Auto-generated method stub
		return matricula.matricula()+"Aluno matriculado no Bacharelado";
	}
}
