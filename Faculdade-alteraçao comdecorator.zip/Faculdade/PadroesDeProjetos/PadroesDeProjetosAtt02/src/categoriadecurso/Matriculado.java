package categoriadecurso;

public abstract class Matriculado implements Matricula {
	protected Matricula matricula;
	
	public Matriculado(Matriculado matricula) {
		this.matricula = matricula;
	}
}
