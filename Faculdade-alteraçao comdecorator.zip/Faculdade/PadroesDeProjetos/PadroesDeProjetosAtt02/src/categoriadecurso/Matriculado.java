package categoriadecurso;

public class Matriculado {

}
