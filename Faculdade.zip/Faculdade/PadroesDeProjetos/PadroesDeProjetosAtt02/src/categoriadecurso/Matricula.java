package categoriadecurso;

public interface Matricula {
	String matricula();
}
